/*
    包含接口域名的模块
 */

export const postURL = 'http://domch.cn/app-api';

export const token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiI5IiwiaXNzIjoienRmZ2ouY29tIiwiZXhwIjoxNTQ1Mzc1NTA4LCJ1c2VySWQiOiIxMDAwMDAwMDIiLCJpYXQiOjE1NDQwNzk1MDh9.vkfTvTi9-Q3KGfOoB8oN_0qFX_WWVM1tmit-aCAziz8'



