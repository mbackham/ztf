'use strict'
module.exports = {
    NODE_ENV: '"preing"',
    ENV_CONFIG:'"pre"'
}
