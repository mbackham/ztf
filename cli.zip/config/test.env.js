'use strict'
module.exports = {
    NODE_ENV: '"testing"',
    ENV_CONFIG:'"test"'
}
